namespace $rootnamespace$;

public class $safeitemrootname$ : $safeitemname$
{
    public $safeitemrootname$()
    {
    }

    public $safeitemrootname$(string? message) : base(message)
    {
    }

    public $safeitemrootname$(string? message, $safeitemname$? innerException) : base(message, innerException)
    {
    }
}
